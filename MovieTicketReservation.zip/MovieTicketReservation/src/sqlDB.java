import java.sql.*;

import javax.swing.JOptionPane;

public class sqlDB {
  public static Connection dbConnector() {
      Connection c = null;
      
      try {
         Class.forName("org.sqlite.JDBC");
         c = DriverManager.getConnection("jdbc:sqlite:test.db");
         JOptionPane.showMessageDialog(null, "Connection Successful");;
         return c;
      } catch ( Exception e ) {
         System.err.println( e.getClass().getName() + ": " + e.getMessage() );
         System.exit(0);
         return null;
      }
   }
}