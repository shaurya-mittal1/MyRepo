import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JFormattedTextField;
import javax.swing.SwingConstants;
import java.awt.Choice;

import javax.sound.midi.SysexMessage;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;

public class MoviesAdder extends JFrame {

	private JPanel contentPane;
	private JTextField textfield_movie;
	private JTextField textField_dur;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MoviesAdder frame = new MoviesAdder();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	Connection c =null;

	/**
	 * Create the frame.
	 */
	public MoviesAdder() {
		
		c=sqlDB.dbConnector();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Movie Name");
		lblNewLabel.setBounds(10, 26, 76, 24);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Duration");
		lblNewLabel_1.setBounds(10, 55, 76, 25);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Show Date");
		lblNewLabel_2.setBounds(10, 91, 76, 24);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Start Time");
		lblNewLabel_3.setBounds(10, 126, 76, 24);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("End Time");
		lblNewLabel_4.setBounds(10, 163, 76, 24);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblAuditorium = new JLabel("Auditorium");
		lblAuditorium.setBounds(10, 198, 69, 24);
		contentPane.add(lblAuditorium);
		
		textfield_movie = new JTextField();
		textfield_movie.setBounds(80, 28, 86, 20);
		contentPane.add(textfield_movie);
		textfield_movie.setColumns(10);
		
		textField_dur = new JTextField();
		textField_dur.setBounds(80, 61, 86, 20);
		contentPane.add(textField_dur);
		textField_dur.setColumns(10);
		
		JFormattedTextField formattedTextField_date = new JFormattedTextField();
		formattedTextField_date.setHorizontalAlignment(SwingConstants.CENTER);
		formattedTextField_date.setBounds(79, 93, 87, 22);
		contentPane.add(formattedTextField_date);
		
		JFormattedTextField formattedTextField_st_time = new JFormattedTextField();
		formattedTextField_st_time.setBounds(80, 126, 86, 24);
		contentPane.add(formattedTextField_st_time);
		
		JFormattedTextField formattedTextField_e_time = new JFormattedTextField();
		formattedTextField_e_time.setBounds(80, 161, 86, 24);
		contentPane.add(formattedTextField_e_time);
		
		Choice choice_audi = new Choice();
		choice_audi.setBounds(80, 202, 86, 20);
		choice_audi.add("A1");
		choice_audi.add("A2");
		choice_audi.add("B1");
		choice_audi.add("B2");
		contentPane.add(choice_audi);
		
		JButton btnAddMovie = new JButton("Add Movie");
		btnAddMovie.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String query = "Insert into Movies (MovieName, Duration, Show_date, start_time, End_time, Auditorium) Values (?,?,?,?,?,?)";
					PreparedStatement pst = c.prepareStatement(query);
					pst.setString(1, textfield_movie.getText());
					pst.setString(2, textField_dur.getText());
					pst.setString(3, formattedTextField_date.getText());
					pst.setString(4, formattedTextField_st_time.getText());
					pst.setString(5, formattedTextField_e_time.getText());
					pst.setString(6, choice_audi.getItem(choice_audi.getSelectedIndex()));
					
					pst.execute();
					JOptionPane.showMessageDialog(null, "Data Updated");
					
					
					
					pst.close();
				} catch (Exception e2) {
					// TODO: handle exception
					JOptionPane.showMessageDialog(null, e2);
				}
			}
		});
		btnAddMovie.setBounds(263, 73, 116, 42);
		contentPane.add(btnAddMovie);
		
		JButton btnNewButton = new JButton("Cancel");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnNewButton.setBounds(263, 127, 116, 42);
		contentPane.add(btnNewButton);
	}
}
