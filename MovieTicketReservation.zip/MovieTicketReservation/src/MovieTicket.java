import java.awt.EventQueue;

import javax.swing.JFrame;
import java.sql.*;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MovieTicket {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MovieTicket window = new MovieTicket();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	Connection c = null;
	

	/**
	 * Create the application.
	 */
	public MovieTicket() {
		initialize();
		c= sqlDB.dbConnector();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnAddMovies = new JButton("Add Movies");
		btnAddMovies.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				MoviesAdder ma = new MoviesAdder();
				ma.setVisible(true);
			}
		});
		btnAddMovies.setBounds(164, 50, 120, 50);
		frame.getContentPane().add(btnAddMovies);
		
		
		JButton btnSearchMovie = new JButton("Search Movie");
		btnSearchMovie.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				SearchMovies sm = new SearchMovies();
				sm.setVisible(true);
			}
		});
		btnSearchMovie.setBounds(164, 163, 120, 50);
		frame.getContentPane().add(btnSearchMovie);
	}
}
